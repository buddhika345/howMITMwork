import socket
import threading
from encryption import encrypt_message, decrypt_message

nickname = input("Enter your name: ")
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("127.0.0.1", 12345))

def receive():
    while True:
        try:
            data = client.recv(4096)
            decrypted = decrypt_message(data)
            print(f"\n{decrypted}")
        except:
            print("[ERROR] Connection lost.")
            break

def send():
    while True:
        message = input()
        encrypted = encrypt_message(f"{nickname}: {message}")
        client.send(encrypted)

threading.Thread(target=receive).start()
threading.Thread(target=send).start()


