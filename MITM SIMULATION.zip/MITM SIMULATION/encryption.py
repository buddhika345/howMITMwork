from cryptography.fernet import Fernet

# Key generation (run once if needed)
# print(Fernet.generate_key())

key = b'jTLCWzN0IV8bWsfPF4GZPOhrIBLUMCikR-nYmn6I9EI='  # Static key for all files
cipher = Fernet(key)

def encrypt_message(msg: str) -> bytes:
    return cipher.encrypt(msg.encode())

def decrypt_message(token: bytes) -> str:
    return cipher.decrypt(token).decode()

