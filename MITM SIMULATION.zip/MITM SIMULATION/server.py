import socket
import threading

clients = []

def handle_client(client):
    while True:
        try:
            data = client.recv(4096)
            for c in clients:
                if c != client:
                    c.send(data)
        except:
            clients.remove(client)
            client.close()
            break

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("127.0.0.1", 12345))
server.listen(2)
print("[INFO] Encrypted Chat Server Started...")

while True:
    client, addr = server.accept()
    print(f"[NEW CONNECTION] {addr}")
    clients.append(client)
    threading.Thread(target=handle_client, args=(client,)).start()

