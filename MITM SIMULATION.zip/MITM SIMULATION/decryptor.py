from encryption import decrypt_message


token_input = input("Enter the encrypted token: ")

try:
    # Convert input string to bytes
    captured_token = token_input.encode()
    
    # Decrypt and display the message
    decrypted_message = decrypt_message(captured_token)
    print("✅ Decrypted message:", decrypted_message)

except Exception as e:
    print("❌ Failed to decrypt the message.")
    print("Error:", e)

